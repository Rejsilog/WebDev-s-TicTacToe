package com.example.finalprojmobapp;


public class User  {


    public String username, email, turl;

    public User(){

    }

    public User(String username, String email, String turl){
        this.username = username;
        this.email = email;
        this.turl = turl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTurl() {
        return turl;
    }

    public void setTurl(String turl) {
        this.turl = turl;
    }


}
