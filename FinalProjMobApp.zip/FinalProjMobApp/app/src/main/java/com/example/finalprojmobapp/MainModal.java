/*
package com.example.finalprojmobapp;

public class MainModal {
    String name, email, score,turl;

    MainModal(){

    }

    public MainModal(String name, String email, String score, String turl) {
        this.name = name;
        this.email = email;
        this.score = score;
        this.turl = turl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getTurl() {
        return turl;
    }

    public void setTurl(String turl) {
        this.turl = turl;
    }
}
*/
