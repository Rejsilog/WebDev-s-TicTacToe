package com.example.finalprojmobapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity implements View.OnClickListener{

    private FirebaseAuth mAuth;
    private EditText etUsername, etEmail, etPassword,etTurl;
    private Button btnRegister, btnLogin;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        progressBar =(ProgressBar) findViewById(R.id.progressBar);

        btnLogin =(Button) findViewById(R.id.btnLog);
        btnLogin.setOnClickListener(this);

        btnRegister = (Button) findViewById(R.id.btnReg);
        btnRegister.setOnClickListener(this);

        etUsername = (EditText) findViewById(R.id.etUsername);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etTurl = (EditText) findViewById(R.id.etTurl);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.btnReg:
                registerUser();
                break;
            case R.id.btnLog:
                goToLogin();
                break;
        }

    }

    private void goToLogin() {
        startActivity(new Intent(Register.this, MainActivity.class));
    }

    private void registerUser() {
        String email = etEmail.getText().toString().trim();
        String username = etUsername.getText().toString();
        String password = etPassword.getText().toString().trim();
        String turl = etTurl.getText().toString().trim();



        if(username.isEmpty()){
            etUsername.setError("Please enter Username.");
            etUsername.requestFocus();
            return;
        }

        if(email.isEmpty()){
            etEmail.setError("Please enter E-mail.");
            etEmail.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            etEmail.setError("Please provide valid E-mail.");
            etEmail.requestFocus();
            return;
        }

        if(password.isEmpty()){
            etPassword.setError("Please enter your Password.");
            etPassword.requestFocus();
            return;
        }

        if(password.length() < 6 ){
            etPassword.setError("Password is too weak! must be 6 characters above.");
            etPassword.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()){
                            User user = new User(username, email, turl);

                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()){
                                                Toast.makeText(Register.this, "Account has been created!",Toast.LENGTH_SHORT).show();
                                                progressBar.setVisibility(View.GONE);
                                                startActivity(new Intent(Register.this, HomeActivity.class));
                                            }else{
                                                Toast.makeText(Register.this, "Registration failed! "+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                                progressBar.setVisibility(View.GONE);
                                            }
                                        }
                                    });
                        }else{
                            Toast.makeText(Register.this, "Registration failed! "+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
    }
}